<?php
	# Responsive retina background images
	if($headerimg = $page->images()->find('#header.png')): ?>
	
	<?php
		// Breakpoints
		$bp_larger_than_mobile = "min-width: 400px";
		$bp_larger_than_phablet = "min-width: 550px";
		$bp_larger_than_tablet = "min-width: 750px";
		$bp_larger_than_desktop = "min-width: 1000px";
		$bp_larger_than_desktophd = "min-width: 1420px";
	?>
	
	<style>			
		@media (max-width: 399px) {
			body.case .header {
				background-image: url(<?php echo thumb($headerimg, array('width' => 960, 'quality' => 70))->url(); ?>);
			}
		
		@media (<?php echo $bp_larger_than_mobile ?>) {
			body.case .header {
				background-image: url(<?php echo thumb($headerimg, array('width' => 1100, 'quality' => 70))->url(); ?>);
			}
		}
		
		@media (<?php echo $bp_larger_than_phablet ?>) {
			body.case .header {
				background-image: url(<?php echo thumb($headerimg, array('width' => 1500, 'quality' => 70))->url(); ?>);
			}
		}
		
		@media (<?php echo $bp_larger_than_tablet ?>) {
			body.case .header {
				background-image: url(<?php echo thumb($headerimg, array('width' => 2000, 'quality' => 70))->url(); ?>);
			}
		}
		
		@media (<?php echo $bp_larger_than_desktop ?>) {
			body.case .header {
				background-image: url(<?php echo thumb($headerimg, array('width' => 2880, 'quality' => 70))->url(); ?>);
			}
		}
	</style>
	
<?php endif ?>